<?php
require_once '../config.php';

try {
    $conn->exec("SET NAMES utf8mb4");
    
    $queries = [
        "SELECT id, 'category' COLLATE utf8mb4_unicode_ci AS option_type, name COLLATE utf8mb4_unicode_ci AS option_value, NULL as parent_id, NULL as option_key FROM categories",
        "SELECT id, 'car_make' COLLATE utf8mb4_unicode_ci AS option_type, name COLLATE utf8mb4_unicode_ci AS option_value, NULL as parent_id, NULL as option_key FROM car_makes",
        "SELECT id, 'car_model' COLLATE utf8mb4_unicode_ci AS option_type, name COLLATE utf8mb4_unicode_ci AS option_value, make_id as parent_id, NULL as option_key FROM car_models",
        "SELECT id, 'car_type' COLLATE utf8mb4_unicode_ci AS option_type, name COLLATE utf8mb4_unicode_ci AS option_value, NULL as parent_id, NULL as option_key FROM car_types",
        "SELECT id, 'vehicle_type' COLLATE utf8mb4_unicode_ci AS option_type, name COLLATE utf8mb4_unicode_ci AS option_value, NULL as parent_id, NULL as option_key FROM vehicle_types",
        "SELECT id, 'fuel_type' COLLATE utf8mb4_unicode_ci AS option_type, name COLLATE utf8mb4_unicode_ci AS option_value, NULL as parent_id, NULL as option_key FROM fuel_types",
        "SELECT id, 'drivetrain' COLLATE utf8mb4_unicode_ci AS option_type, name COLLATE utf8mb4_unicode_ci AS option_value, NULL as parent_id, NULL as option_key FROM drivetrains",
        "SELECT id, 'price_option' COLLATE utf8mb4_unicode_ci AS option_type, name COLLATE utf8mb4_unicode_ci AS option_value, NULL as parent_id, option_key COLLATE utf8mb4_unicode_ci FROM price_options"
    ];

    $fullQuery = implode(" UNION ALL ", $queries);
    $stmt = $conn->query($fullQuery);
    $options = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "SUCCESS: Found " . count($options) . " rows.\n";
} catch (PDOException $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
?>
